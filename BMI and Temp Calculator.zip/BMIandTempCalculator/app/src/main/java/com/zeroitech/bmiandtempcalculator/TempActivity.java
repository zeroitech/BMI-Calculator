package com.zeroitech.bmiandtempcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class TempActivity extends AppCompatActivity {

    TextView showD,showD2;
    EditText selsias, farenH;
    Button convertF, convertC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);

        showD = findViewById(R.id.showD);
        showD2 = findViewById(R.id.showD2);
        selsias = findViewById(R.id.selsias);
        farenH = findViewById(R.id.farenH);
        convertF = findViewById(R.id.convertF);
        convertC = findViewById(R.id.convertC);

        convertF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String celcius = selsias.getText().toString();

                float C = Float.parseFloat(celcius);
                float F = C * 9/5 +32 ;

                showD.setText("Temp F = " + F);

            }
        });
        convertC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String faren = farenH.getText().toString();

                float F1 = Float.parseFloat(faren);
                float C1 = (F1-32) * 5/9 ;

                showD2.setText("Temp C = " + C1);

            }
        });








    }//==================oncreate method end=========///
}