package com.zeroitech.bmiandtempcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView display;
    EditText weight,feet,inch;
    Button bmical,tempAct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        weight = findViewById(R.id.weight);
        feet = findViewById(R.id.feet);
        inch = findViewById(R.id.inch);
        bmical = findViewById(R.id.bmical);
        tempAct = findViewById(R.id.tempAct);


        bmical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String Sweight = weight.getText().toString();
                String sfeet = feet.getText().toString();
                String sinch = inch.getText().toString();

                float Weight = Float.parseFloat(Sweight);
                float sFeet = Float.parseFloat(sfeet);
                float sInch = Float.parseFloat(sinch);

                float height = (float) (sFeet*0.3048 + sInch*0.0254);
                float BMIindex = Weight / (height*height);

                display.setText("Youre BMI Is: " + BMIindex);

            }
        });

        tempAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, TempActivity.class);
                startActivity(i);
            }
        });





    }//================Oncreated End======================///
}